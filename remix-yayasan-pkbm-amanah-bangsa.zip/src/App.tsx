import React, { useState } from 'react';
import { Check, Copy, ArrowUpRight, Send } from 'lucide-react';
import {
  INSTITUTIONAL_PROFILE,
  INSTITUTIONAL_REGISTRY,
  EDUCATIONAL_PROGRAMS,
  MISSION_POINTS,
  EducationalProgram,
} from './data/pkbmData';

type ProgramFilter = 'all' | EducationalProgram['category'];

export default function App() {
  const [selectedFilter, setSelectedFilter] = useState<ProgramFilter>('all');
  const [copiedNpsn, setCopiedNpsn] = useState(false);

  // Form state
  const [fullName, setFullName] = useState('');
  const [phoneInput, setPhoneInput] = useState('');
  const [programChoice, setProgramChoice] = useState('Program Paket C (Setara SMA)');
  const [notes, setNotes] = useState('');
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [formError, setFormError] = useState('');

  const filteredPrograms =
    selectedFilter === 'all'
      ? EDUCATIONAL_PROGRAMS
      : EDUCATIONAL_PROGRAMS.filter((item) => item.category === selectedFilter);

  const handleCopyNpsn = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(INSTITUTIONAL_PROFILE.npsn);
    }
    setCopiedNpsn(true);
    setTimeout(() => setCopiedNpsn(false), 2000);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName.trim() || !phoneInput.trim()) {
      setFormError('Mohon lengkapi nama lengkap dan nomor kontak yang dapat dihubungi.');
      return;
    }
    setFormError('');
    setFormSubmitted(true);
  };

  const handleResetForm = () => {
    setFullName('');
    setPhoneInput('');
    setProgramChoice('Program Paket C (Setara SMA)');
    setNotes('');
    setFormSubmitted(false);
    setFormError('');
  };

  return (
    <div className="min-h-screen bg-[#FBF9F5] text-[#1C1917] selection:bg-[#14532D] selection:text-white">
      {/* Top Bar Contract: 3 zones separated by gap-8 */}
      <header className="sticky top-0 z-30 bg-[#FBF9F5]/95 backdrop-blur-sm border-b border-stone-200">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between gap-8">
          {/* Zone 1: Single-line Brand Wordmark */}
          <a
            href="#beranda"
            className="font-display text-lg font-semibold tracking-tight text-stone-900 whitespace-nowrap shrink-0"
          >
            {INSTITUTIONAL_PROFILE.shortName}
          </a>

          {/* Zone 2: 4 concise single-line nav links */}
          <nav
            aria-label="Navigasi Utama"
            className="hidden md:flex items-center gap-6 text-sm font-medium text-stone-600"
          >
            <a
              href="#profil"
              className="hover:text-stone-900 transition-colors whitespace-nowrap shrink-0"
            >
              Profil
            </a>
            <a
              href="#program"
              className="hover:text-stone-900 transition-colors whitespace-nowrap shrink-0"
            >
              Program
            </a>
            <a
              href="#data-pokok"
              className="hover:text-stone-900 transition-colors whitespace-nowrap shrink-0"
            >
              Data Pokok
            </a>
            <a
              href="#pendaftaran"
              className="hover:text-stone-900 transition-colors whitespace-nowrap shrink-0"
            >
              Pendaftaran
            </a>
          </nav>

          {/* Zone 3: 1 Primary Action */}
          <div className="flex items-center shrink-0">
            <a
              href="#pendaftaran"
              className="px-4 py-2 text-xs font-semibold text-white bg-[#14532D] rounded-lg hover:bg-[#166534] transition-colors whitespace-nowrap shrink-0"
            >
              Daftar Sekarang
            </a>
          </div>
        </div>
      </header>

      <main>
        {/* Hero Section */}
        <section id="beranda" className="max-w-6xl mx-auto px-6 pt-12 pb-16 lg:pt-20 lg:pb-24">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-stretch">
            {/* Left Editorial Column */}
            <div className="lg:col-span-6 flex flex-col justify-between">
              <div>
                <p className="text-xs uppercase tracking-widest text-stone-500 font-medium">
                  Yayasan · Pusat Kegiatan Belajar Masyarakat
                </p>
                <h1
                  className="mt-4 text-4xl sm:text-5xl font-semibold tracking-tight text-stone-900 leading-[1.12]"
                  style={{ textWrap: 'balance' }}
                >
                  Membuka Akses Pendidikan Kesetaraan yang Bermartabat
                </h1>
                <p className="mt-6 text-base sm:text-lg text-stone-600 leading-relaxed max-w-xl">
                  Yayasan PKBM Amanah Bangsa menyelenggarakan layanan pendidikan nonformal
                  melalui Program Paket A, Paket B, Paket C, serta pelatihan keterampilan
                  masyarakat dengan tata kelola yang amanah dan inklusif.
                </p>
              </div>

              <div className="mt-8 pt-6 border-t border-stone-200 flex flex-wrap items-center gap-4">
                <a
                  href="#pendaftaran"
                  className="px-5 py-3 text-sm font-semibold text-white bg-[#14532D] rounded-lg hover:bg-[#166534] transition-colors inline-flex items-center gap-2 whitespace-nowrap shrink-0"
                >
                  <span>Daftar Peserta Didik</span>
                  <ArrowUpRight className="w-4 h-4" aria-hidden="true" />
                </a>
                <a
                  href="#data-pokok"
                  className="px-5 py-3 text-sm font-medium text-stone-800 bg-white border border-stone-300 rounded-lg hover:bg-stone-100 transition-colors whitespace-nowrap shrink-0"
                >
                  Lihat Data Pokok
                </a>
              </div>
            </div>

            {/* Right Documentary Media Column */}
            <div className="lg:col-span-6 flex flex-col">
              <div className="relative w-full h-72 sm:h-96 lg:h-full min-h-[320px] rounded-xl overflow-hidden bg-stone-200 border border-stone-200">
                <img
                  src="/src/assets/images/pkbm_hero_classroom_1793895767345.jpg"
                  alt="Suasana kegiatan belajar mengajar warga belajar di PKBM Amanah Bangsa"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>
              <p className="mt-2.5 text-xs font-serif italic text-stone-500">
                Fig. 1 — Kegiatan pembelajaran tatap muka dan pendampingan modul warga belajar.
              </p>
            </div>
          </div>

          {/* 4-Column Institutional Strip below Hero Split */}
          <div className="mt-12 grid grid-cols-2 lg:grid-cols-4 border border-stone-200 bg-white rounded-xl divide-y lg:divide-y-0 lg:divide-x divide-stone-200">
            <div className="p-5">
              <p className="text-xs uppercase tracking-wider text-stone-500">NPSN</p>
              <p className="mt-1.5 text-xl font-semibold text-stone-900 font-mono-tabular">
                {INSTITUTIONAL_PROFILE.npsn}
              </p>
            </div>
            <div className="p-5">
              <p className="text-xs uppercase tracking-wider text-stone-500">Akreditasi</p>
              <p className="mt-1.5 text-xl font-semibold text-stone-900 font-mono-tabular">
                Peringkat {INSTITUTIONAL_PROFILE.accreditation}
              </p>
            </div>
            <div className="p-5">
              <p className="text-xs uppercase tracking-wider text-stone-500">Status & Naungan</p>
              <p className="mt-1.5 text-xl font-semibold text-stone-900">
                {INSTITUTIONAL_PROFILE.status} · {INSTITUTIONAL_PROFILE.foundation}
              </p>
            </div>
            <div className="p-5">
              <p className="text-xs uppercase tracking-wider text-stone-500">Bentuk Pendidikan</p>
              <p className="mt-1.5 text-xl font-semibold text-stone-900">
                {INSTITUTIONAL_PROFILE.educationForm}
              </p>
            </div>
          </div>
        </section>

        {/* Profil & Visi Misi Section */}
        <section id="profil" className="border-t border-stone-200 bg-white py-16 lg:py-24">
          <div className="max-w-6xl mx-auto px-6">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
              <div className="lg:col-span-5">
                <p className="text-xs uppercase tracking-widest text-stone-500 font-medium">
                  Profil Kelembagaan
                </p>
                <h2 className="mt-3 text-3xl sm:text-4xl font-semibold text-stone-900 leading-tight">
                  Pendidikan Sepanjang Hayat untuk Kemandirian Bangsa
                </h2>
                <p className="mt-5 text-base text-stone-600 leading-relaxed">
                  Sebagai Pusat Kegiatan Belajar Masyarakat (PKBM) di bawah naungan Yayasan,
                  PKBM Amanah Bangsa hadir menjembatani kebutuhan pendidikan masyarakat yang
                  memerlukan layanan kesetaraan formal maupun penguatan keterampilan hidup.
                </p>

                <div className="mt-8 rounded-xl overflow-hidden border border-stone-200 bg-stone-100 aspect-[4/3]">
                  <img
                    src="/src/assets/images/pkbm_vocational_workshop_1793895768147.jpg"
                    alt="Pelatihan keterampilan dan literasi digital warga belajar"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </div>
                <p className="mt-2.5 text-xs font-serif italic text-stone-500">
                  Fig. 2 — Pendampingan keterampilan vokasional dan literasi masyarakat.
                </p>
              </div>

              <div className="lg:col-span-7">
                <blockquote className="py-6 border-y border-stone-200">
                  <p className="font-display italic text-2xl sm:text-3xl text-stone-800 leading-snug">
                    “Setiap warga negara berhak mendapatkan kesempatan belajar yang layak,
                    fleksibel, dan diakui negara demi masa depan yang lebih baik.”
                  </p>
                  <footer className="mt-3 text-xs uppercase tracking-widest text-stone-500">
                    Komitmen Yayasan PKBM Amanah Bangsa
                  </footer>
                </blockquote>

                <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 gap-8">
                  {MISSION_POINTS.map((item) => (
                    <div key={item.number} className="pt-4 border-t border-stone-200">
                      <span className="font-mono-tabular text-xs font-medium text-[#78350F]">
                        {item.number}
                      </span>
                      <h3 className="mt-2 text-lg font-semibold text-stone-900">{item.title}</h3>
                      <p className="mt-2 text-sm text-stone-600 leading-relaxed">
                        {item.description}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Program Pendidikan Kesetaraan (Interactive Filterable Catalog) */}
        <section id="program" className="border-t border-stone-200 bg-[#FBF9F5] py-16 lg:py-24">
          <div className="max-w-6xl mx-auto px-6">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
              <div>
                <p className="text-xs uppercase tracking-widest text-stone-500 font-medium">
                  Layanan Pendidikan
                </p>
                <h2 className="mt-2 text-3xl sm:text-4xl font-semibold text-stone-900">
                  Program Kesetaraan & Keterampilan
                </h2>
              </div>

              {/* Interactive Segmented Filter Controls */}
              <div
                role="tablist"
                aria-label="Filter Program Pendidikan"
                className="flex flex-wrap items-center gap-1.5 p-1 bg-stone-200/70 rounded-lg"
              >
                {[
                  { id: 'all', label: 'Semua Program' },
                  { id: 'paket-a', label: 'Paket A' },
                  { id: 'paket-b', label: 'Paket B' },
                  { id: 'paket-c', label: 'Paket C' },
                  { id: 'keterampilan', label: 'Keterampilan' },
                ].map((tab) => {
                  const active = selectedFilter === tab.id;
                  return (
                    <button
                      key={tab.id}
                      role="tab"
                      aria-selected={active}
                      onClick={() => setSelectedFilter(tab.id as ProgramFilter)}
                      className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                        active
                          ? 'bg-white text-stone-900 shadow-sm'
                          : 'text-stone-600 hover:text-stone-900'
                      }`}
                    >
                      {tab.label}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="mt-10 grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredPrograms.map((program) => (
                <article
                  key={program.id}
                  className="bg-white border border-stone-200 rounded-xl p-6 sm:p-8 flex flex-col justify-between"
                >
                  <div>
                    <p className="text-xs text-stone-500 font-medium">{program.kicker}</p>
                    <h3 className="mt-2 text-2xl font-semibold text-stone-900">{program.title}</h3>
                    <div className="mt-2 flex flex-wrap items-center gap-2 text-xs text-stone-500">
                      <span>{program.duration}</span>
                      <span aria-hidden="true">·</span>
                      <span>{program.schedule}</span>
                    </div>
                    <p className="mt-4 text-sm sm:text-base text-stone-600 leading-relaxed">
                      {program.summary}
                    </p>

                    <ul className="mt-5 pt-5 border-t border-stone-100 space-y-2 text-sm text-stone-700">
                      {program.competencies.map((comp, idx) => (
                        <li key={idx} className="flex items-start gap-2.5">
                          <span className="text-[#14532D] font-semibold select-none">—</span>
                          <span>{comp}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="mt-6 pt-4 border-t border-stone-100 flex items-center justify-between">
                    <span className="text-xs font-medium text-stone-500">
                      {program.equivalent}
                    </span>
                    <a
                      href="#pendaftaran"
                      onClick={() => setProgramChoice(`${program.title} (${program.equivalent})`)}
                      className="text-xs font-semibold text-[#14532D] hover:underline inline-flex items-center gap-1 whitespace-nowrap shrink-0"
                    >
                      <span>Daftar Program</span>
                      <ArrowUpRight className="w-3.5 h-3.5" aria-hidden="true" />
                    </a>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* Data Pokok Lembaga (Institutional Registry) */}
        <section id="data-pokok" className="border-t border-stone-200 bg-white py-16 lg:py-24">
          <div className="max-w-6xl mx-auto px-6">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
              <div className="lg:col-span-4">
                <p className="text-xs uppercase tracking-widest text-stone-500 font-medium">
                  Identitas Resmi
                </p>
                <h2 className="mt-2 text-3xl font-semibold text-stone-900">
                  Data Pokok Satuan Pendidikan
                </h2>
                <p className="mt-4 text-sm text-stone-600 leading-relaxed">
                  Informasi kelembagaan resmi Yayasan PKBM Amanah Bangsa sesuai catatan data
                  pokok pendidikan nasional.
                </p>

                <div className="mt-6">
                  <button
                    type="button"
                    onClick={handleCopyNpsn}
                    className="px-4 py-2.5 text-xs font-medium text-stone-800 bg-[#FBF9F5] border border-stone-300 rounded-lg hover:bg-stone-100 transition-colors inline-flex items-center gap-2 whitespace-nowrap shrink-0"
                  >
                    {copiedNpsn ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-[#14532D]" aria-hidden="true" />
                        <span>NPSN P2970447 Disalin</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5 text-stone-500" aria-hidden="true" />
                        <span>Salin NPSN (P2970447)</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              <div className="lg:col-span-8">
                <dl className="divide-y divide-stone-200 border-y border-stone-200">
                  {INSTITUTIONAL_REGISTRY.map((field) => (
                    <div
                      key={field.label}
                      className="py-4 flex flex-col sm:flex-row sm:items-baseline justify-between gap-1 sm:gap-6"
                    >
                      <dt className="text-sm font-medium text-stone-500">{field.label}</dt>
                      <dd className="text-sm sm:text-base font-medium text-stone-900 sm:text-right">
                        <span className={field.isMono ? 'font-mono-tabular' : ''}>
                          {field.value}
                        </span>
                        {field.note && (
                          <span className="block text-xs font-normal text-stone-400 mt-0.5">
                            {field.note}
                          </span>
                        )}
                      </dd>
                    </div>
                  ))}
                </dl>
              </div>
            </div>
          </div>
        </section>

        {/* Pendaftaran & Kontak Section */}
        <section id="pendaftaran" className="border-t border-stone-200 bg-[#FBF9F5] py-16 lg:py-24">
          <div className="max-w-6xl mx-auto px-6">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
              <div className="lg:col-span-5">
                <p className="text-xs uppercase tracking-widest text-stone-500 font-medium">
                  Penerimaan Warga Belajar
                </p>
                <h2 className="mt-2 text-3xl sm:text-4xl font-semibold text-stone-900">
                  Formulir Pendaftaran & Informasi
                </h2>
                <p className="mt-4 text-base text-stone-600 leading-relaxed">
                  Calon peserta didik atau orang tua/wali dapat mengajukan pendaftaran awal atau
                  permintaan informasi jadwal belajar melalui formulir ini.
                </p>

                <div className="mt-8 pt-6 border-t border-stone-200 space-y-3 text-sm text-stone-600">
                  <p>
                    <strong className="font-semibold text-stone-900">Lembaga:</strong> Yayasan PKBM
                    Amanah Bangsa
                  </p>
                  <p>
                    <strong className="font-semibold text-stone-900">NPSN:</strong>{' '}
                    <span className="font-mono-tabular">P2970447</span>
                  </p>
                  <p>
                    <strong className="font-semibold text-stone-900">Status & Akreditasi:</strong>{' '}
                    Swasta · Akreditasi C
                  </p>
                </div>
              </div>

              <div className="lg:col-span-7">
                <div className="bg-white border border-stone-200 rounded-xl p-6 sm:p-8">
                  {formSubmitted ? (
                    <div className="py-6">
                      <p className="text-xs uppercase tracking-widest text-[#14532D] font-semibold">
                        Pengajuan Tercatat
                      </p>
                      <h3 className="mt-2 text-2xl font-semibold text-stone-900">
                        Terima kasih, {fullName}
                      </h3>
                      <p className="mt-3 text-sm text-stone-600 leading-relaxed">
                        Data pendaftaran awal Anda untuk{' '}
                        <strong className="text-stone-900">{programChoice}</strong> telah dicatat.
                        Pengurus Yayasan PKBM Amanah Bangsa akan menindaklanjuti melalui nomor{' '}
                        <span className="font-mono-tabular text-stone-900">{phoneInput}</span>.
                      </p>
                      <button
                        type="button"
                        onClick={handleResetForm}
                        className="mt-6 px-4 py-2 text-xs font-semibold text-stone-800 bg-stone-100 rounded-lg hover:bg-stone-200 transition-colors"
                      >
                        Kirim Pengajuan Lain
                      </button>
                    </div>
                  ) : (
                    <form onSubmit={handleFormSubmit} className="space-y-5" noValidate>
                      <div>
                        <label
                          htmlFor="fullName"
                          className="block text-sm font-medium text-stone-800"
                        >
                          Nama Lengkap Calon Warga Belajar
                        </label>
                        <input
                          id="fullName"
                          type="text"
                          value={fullName}
                          onChange={(e) => setFullName(e.target.value)}
                          placeholder="Contoh: Ahmad Fauzi"
                          className="mt-1.5 w-full px-3.5 py-2.5 text-sm bg-[#FBF9F5] border border-stone-300 rounded-lg focus:outline-none focus:border-[#14532D]"
                          required
                        />
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                        <div>
                          <label
                            htmlFor="phoneInput"
                            className="block text-sm font-medium text-stone-800"
                          >
                            Nomor Telepon / WhatsApp
                          </label>
                          <input
                            id="phoneInput"
                            type="tel"
                            value={phoneInput}
                            onChange={(e) => setPhoneInput(e.target.value)}
                            placeholder="08xx-xxxx-xxxx"
                            className="mt-1.5 w-full px-3.5 py-2.5 text-sm bg-[#FBF9F5] border border-stone-300 rounded-lg focus:outline-none focus:border-[#14532D]"
                            required
                          />
                        </div>

                        <div>
                          <label
                            htmlFor="programChoice"
                            className="block text-sm font-medium text-stone-800"
                          >
                            Program yang Diminati
                          </label>
                          <select
                            id="programChoice"
                            value={programChoice}
                            onChange={(e) => setProgramChoice(e.target.value)}
                            className="mt-1.5 w-full px-3.5 py-2.5 text-sm bg-[#FBF9F5] border border-stone-300 rounded-lg focus:outline-none focus:border-[#14532D]"
                          >
                            <option value="Program Paket A (Setara Sekolah Dasar)">
                              Program Paket A (Setara SD)
                            </option>
                            <option value="Program Paket B (Setara Sekolah Menengah Pertama)">
                              Program Paket B (Setara SMP)
                            </option>
                            <option value="Program Paket C (Setara Sekolah Menengah Atas)">
                              Program Paket C (Setara SMA)
                            </option>
                            <option value="Pendidikan Keaksaraan & Keterampilan">
                              Keaksaraan & Keterampilan
                            </option>
                          </select>
                        </div>
                      </div>

                      <div>
                        <label
                          htmlFor="notes"
                          className="block text-sm font-medium text-stone-800"
                        >
                          Catatan Tambahan (Opsional)
                        </label>
                        <textarea
                          id="notes"
                          rows={3}
                          value={notes}
                          onChange={(e) => setNotes(e.target.value)}
                          placeholder="Tuliskan pendidikan terakhir atau pertanyaan mengenai jadwal belajar..."
                          className="mt-1.5 w-full px-3.5 py-2.5 text-sm bg-[#FBF9F5] border border-stone-300 rounded-lg focus:outline-none focus:border-[#14532D]"
                        />
                      </div>

                      {formError && (
                        <p role="alert" className="text-xs font-medium text-red-700">
                          {formError}
                        </p>
                      )}

                      <button
                        type="submit"
                        className="w-full sm:w-auto px-6 py-3 text-sm font-semibold text-white bg-[#14532D] rounded-lg hover:bg-[#166534] transition-colors inline-flex items-center justify-center gap-2"
                      >
                        <Send className="w-4 h-4" aria-hidden="true" />
                        <span>Kirim Pendaftaran</span>
                      </button>
                    </form>
                  )}
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Quiet Institutional Footer */}
      <footer className="border-t border-stone-200 bg-white py-10">
        <div className="max-w-6xl mx-auto px-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs text-stone-500">
          <div>
            <p className="font-semibold text-stone-900">{INSTITUTIONAL_PROFILE.name}</p>
            <p className="mt-1">
              NPSN {INSTITUTIONAL_PROFILE.npsn} · Status {INSTITUTIONAL_PROFILE.status} ·
              Akreditasi {INSTITUTIONAL_PROFILE.accreditation}
            </p>
          </div>
          <p>© {new Date().getFullYear()} Yayasan PKBM Amanah Bangsa.</p>
        </div>
      </footer>
    </div>
  );
}
