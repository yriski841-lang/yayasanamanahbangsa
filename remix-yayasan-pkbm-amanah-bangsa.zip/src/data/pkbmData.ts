export interface InstitutionalField {
  label: string;
  value: string;
  isMono?: boolean;
  note?: string;
}

export interface EducationalProgram {
  id: string;
  category: 'paket-a' | 'paket-b' | 'paket-c' | 'keterampilan';
  kicker: string;
  title: string;
  equivalent: string;
  duration: string;
  schedule: string;
  summary: string;
  competencies: string[];
}

export const INSTITUTIONAL_PROFILE = {
  name: 'Yayasan PKBM Amanah Bangsa',
  shortName: 'PKBM Amanah Bangsa',
  npsn: 'P2970447',
  accreditation: 'C',
  status: 'Swasta',
  educationForm: 'PKBM',
  foundation: 'Yayasan',
  phone: '—',
  email: '—',
  websiteStatus: 'Belum Terisi',
};

export const INSTITUTIONAL_REGISTRY: InstitutionalField[] = [
  { label: 'Nama Satuan Pendidikan', value: 'PKBM Amanah Bangsa' },
  { label: 'Naungan Lembaga', value: 'Yayasan' },
  { label: 'NPSN', value: 'P2970447', isMono: true },
  { label: 'Bentuk Pendidikan', value: 'PKBM (Pusat Kegiatan Belajar Masyarakat)' },
  { label: 'Status Sekolah', value: 'Swasta' },
  { label: 'Akreditasi', value: 'C', isMono: true },
  { label: 'Telepon', value: '—', note: 'Belum terisi pada data pokok' },
  { label: 'Email', value: '—', note: 'Belum terisi pada data pokok' },
  { label: 'Website Sekolah', value: 'Belum Terisi', note: 'Portal informasi resmi' },
];

export const EDUCATIONAL_PROGRAMS: EducationalProgram[] = [
  {
    id: 'paket-a',
    category: 'paket-a',
    kicker: 'Pendidikan Dasar · Setara SD/MI',
    title: 'Program Paket A',
    equivalent: 'Setara Sekolah Dasar',
    duration: '6 Tahun (atau percepatan sesuai asesmen)',
    schedule: 'Tatap Muka & Tutorial Mandiri',
    summary:
      'Layanan pendidikan kesetaraan tingkat dasar yang membangun fondasi literasi, numerasi, budi pekerti, serta kecakapan hidup sehari-hari bagi peserta didik usia sekolah maupun dewasa.',
    competencies: [
      'Penguatan membaca, menulis, dan berhitung fungsional',
      'Pendidikan kewarganegaraan dan karakter kebangsaan',
      'Ijazah resmi negara yang diakui untuk melanjutkan ke Paket B / SMP',
    ],
  },
  {
    id: 'paket-b',
    category: 'paket-b',
    kicker: 'Pendidikan Menengah Pertama · Setara SMP/MTs',
    title: 'Program Paket B',
    equivalent: 'Setara Sekolah Menengah Pertama',
    duration: '3 Tahun (Tingkatan 3 & 4)',
    schedule: 'Fleksibel · Pagi / Sore / Akhir Pekan',
    summary:
      'Program kesetaraan menengah pertama yang dirancang untuk memperluas wawasan akademik, pemecahan masalah, serta kesiapan menghadapi dunia kerja maupun jenjang menengah atas.',
    competencies: [
      'Kurikulum nasional kesetaraan berbasis modul terstruktur',
      'Pendampingan tutor berpengalaman secara luring dan daring',
      'Ijazah setara SMP/MTs untuk melanjutkan ke Paket C / SMA / SMK',
    ],
  },
  {
    id: 'paket-c',
    category: 'paket-c',
    kicker: 'Pendidikan Menengah Atas · Setara SMA/MA',
    title: 'Program Paket C',
    equivalent: 'Setara Sekolah Menengah Atas',
    duration: '3 Tahun (Tingkatan 5 & 6)',
    schedule: 'Fleksibel · Kelas Reguler & Karyawan',
    summary:
      'Pendidikan kesetaraan tingkat atas yang membekali peserta didik dengan kompetensi akademik, literasi digital, dan kesiapan melanjutkan ke perguruan tinggi atau dunia usaha.',
    competencies: [
      'Peminatan Ilmu Pengetahuan Sosial & Bahasa',
      'Persiapan ujian kesetaraan dan seleksi perguruan tinggi',
      'Ijazah resmi setara SMA/MA yang diakui secara nasional',
    ],
  },
  {
    id: 'keterampilan',
    category: 'keterampilan',
    kicker: 'Pemberdayaan Masyarakat · Vokasi & Literasi',
    title: 'Pendidikan Keaksaraan & Keterampilan',
    equivalent: 'Program Kecakapan Hidup',
    duration: '3 – 6 Bulan per Angkatan',
    schedule: 'Praktik Langsung & Pendampingan Usaha',
    summary:
      'Pelatihan keterampilan praktis dan keaksaraan fungsional untuk mendorong kemandirian ekonomi warga belajar serta pemberdayaan komunitas sekitar.',
    competencies: [
      'Pelatihan administrasi perkantoran & literasi komputer dasar',
      'Kewirausahaan mikro dan pengelolaan keuangan keluarga',
      'Sertifikat kompetensi lembaga sebagai bekal kerja mandiri',
    ],
  },
];

export const MISSION_POINTS = [
  {
    number: '01.',
    title: 'Akses Pendidikan Inklusif',
    description:
      'Menyelenggarakan layanan pendidikan kesetaraan yang terbuka bagi seluruh lapisan masyarakat tanpa memandang usia maupun latar belakang sosial.',
  },
  {
    number: '02.',
    title: 'Pembelajaran Fleksibel & Bermutu',
    description:
      'Menghadirkan metode belajar tatap muka, tutorial, dan mandiri yang menyesuaikan ritme warga belajar yang bekerja maupun mengurus keluarga.',
  },
  {
    number: '03.',
    title: 'Penguatan Karakter & Kemandirian',
    description:
      'Memadukan capaian akademik dengan pembentukan akhlak mulia, etos kerja, serta keterampilan vokasional yang relevan dengan kebutuhan lokal.',
  },
  {
    number: '04.',
    title: 'Tata Kelola Yayasan yang Amanah',
    description:
      'Mengelola satuan pendidikan secara transparan, akuntabel, dan berkesinambungan di bawah naungan Yayasan PKBM Amanah Bangsa.',
  },
];
